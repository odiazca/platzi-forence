1. Start USB_Write_Blocker_ALL_Windows_v1.3.bat

3. Type 1 (To enable the write blocker) and press Enter

4. Wait until you see "The USB Write Blocker is - ON" and press Enter

5. Type 3 and press Enter (if you want to exit)

6. You can connect your USB Flash Drive.

7. Try it !


*** Never change the settings of the write blocker when a USB Flash Drive is connected. ***


If the write blocker doesn't work make sure that your BIOS and all USB drivers are up to date.

If you have any questions or problems send an email to - support@securitemulti-secteurs.ca


*** Works with Windows XP SP2 and newer. ***

TESTED on Windows 8